#!/bin/bash

git config --global user.name "Guilherme Medeiros"
git config --global user.email "guilherme.alth@gmail.com"


