clc;
clear all;
close all;

global i;

i = 0;