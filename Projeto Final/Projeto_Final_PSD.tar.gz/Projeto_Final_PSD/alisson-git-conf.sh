#!/bin/bash

git config --global user.name "Alisson Boeing"
git config --global user.email "alisson.b11@aluno.ifsc.edu.br"


